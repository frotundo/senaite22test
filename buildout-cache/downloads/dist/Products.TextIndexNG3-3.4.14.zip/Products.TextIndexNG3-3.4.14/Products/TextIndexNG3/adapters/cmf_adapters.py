###########################################################################
# TextIndexNG V 3
# The next generation TextIndex for Zope
#
# This software is governed by a license. See
# LICENSE.txt for the terms of this license.
###########################################################################

"""
A collection of adapter to provide better indexing support for
CMF derived types.

$Id: cmf_adapters.py 2305 2011-03-18 21:53:07Z patrick_gerken $
"""

from zope.component import adapts
from zope.interface import implements

from Products.CMFCore.interfaces import IContentish
from Products.CMFCore.utils import getToolByName

from zopyx.txng3.core.interfaces import IIndexableContent
from zopyx.txng3.core.content import IndexContentCollector as ICC
from zopyx.txng3.core.logger import LOG
from zopyx.txng3.core.config import DEFAULT_LANGUAGE


class CMFContentAdapter:

    """An adapter for CMF content.
    """

    adapts(IContentish)
    implements(IIndexableContent)

    def __init__(self, context):
        self.context = context
        self.encoding = 'utf-8'
        try:
            if callable(context.Language):
                self.language = context.Language()
            else:
                self.language = context.Language # plone.app.multilingual
        except AttributeError:
            self.language = DEFAULT_LANGUAGE

    def _c(self, text):
        if isinstance(text, unicode):
            return text
        try:
            return unicode(text, self.encoding)
        except UnicodeDecodeError:
            LOG.warn('Content from %s could not be converted to unicode using the site encoding %s' %
                    (self.context.absolute_url(1), self.encoding))
            raise

    def indexableContent(self, fields):
        icc = ICC()
        if 'getId' in fields:
            self.addIdField(icc)
        if 'Title' in fields:
            self.addTitleField(icc)
        if 'Description' in fields:
            self.addDescriptionField(icc)
        if 'SearchableText' in fields:
            self.addSearchableTextField(icc)
        return icc

    def addIdField(self, icc):
        try:
            id = self._c(self.context.getId())
        except TypeError:
            id = self._c(self.context.getId)
        icc.addContent('getId', id, self.language)

    def addTitleField(self, icc):
        try:
            title = self._c(self.context.Title())
        except TypeError:
            title = self._c(self.context.Title)
        icc.addContent('Title', title, self.language)

    def addDescriptionField(self, icc):
        try:
            description = self._c(self.context.Description())
        except TypeError:
            description = self._c(self.context.Description)
        icc.addContent('Description', description, self.language)

    def addSearchableTextField(self, icc):
        try:
            text = self._c(self.context.SearchableText())
        except TypeError:
            text = self._c(self.context.SearchableText)
        icc.addContent('SearchableText', text, self.language)


