This folder provides a collection of Zope 3 adapters to provide the
IIndexableContent API for content-types to TextIndexNG3.

