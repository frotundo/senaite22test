# -*- coding: utf-8 -*-
from plone.rest.service import Service  # noqa
