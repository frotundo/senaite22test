
from grok.index import IndexDefinition
from ting import TingIndex

class TXNGIndex(IndexDefinition):
    index_class = TingIndex
