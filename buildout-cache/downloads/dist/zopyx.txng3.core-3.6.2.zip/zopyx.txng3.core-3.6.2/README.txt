TextIndexNG3 core implementation
================================
