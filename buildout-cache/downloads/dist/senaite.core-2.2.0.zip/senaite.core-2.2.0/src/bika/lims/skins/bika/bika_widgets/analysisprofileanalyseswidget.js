// Helper JS for bika_widgets/analysisprofileanalyseswidget.pt
