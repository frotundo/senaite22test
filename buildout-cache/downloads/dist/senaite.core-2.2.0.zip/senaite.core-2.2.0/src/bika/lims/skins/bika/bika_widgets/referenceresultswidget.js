// Helper JS for bika_widgets/referenceresultswidget.pt
