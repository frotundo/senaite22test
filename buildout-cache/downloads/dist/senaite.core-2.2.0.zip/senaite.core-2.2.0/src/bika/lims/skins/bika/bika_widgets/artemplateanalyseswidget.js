// Helper JS for bika_widgets/artemplateanalyseswidget.pt
