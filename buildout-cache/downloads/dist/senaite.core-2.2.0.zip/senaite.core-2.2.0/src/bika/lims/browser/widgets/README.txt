Widgets
=======

These are the main archetype widget classes, and utility methods for widgets.

The js, css and pt files for each widget lives in skins/bika/bika_widgets.

