# Installation Guide

Install a Python 2.7 virtual environment.

Install the `requirements.txt` with `pip` from the virtual environment:

    pip install -r requirements.txt

Run `buildout`:

    buildout -v
