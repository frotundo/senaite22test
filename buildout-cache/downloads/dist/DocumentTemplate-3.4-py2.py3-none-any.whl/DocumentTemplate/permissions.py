change_dtml_documents = 'Change DTML Documents'
change_dtml_methods = 'Change DTML Methods'
