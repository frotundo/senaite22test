from zope.publisher.interfaces.browser import IDefaultBrowserLayer


class IDefaultPloneLayer(IDefaultBrowserLayer):
    """A Zope 3 browser layer corresponding to Plone defaults
    """
