============
 To-Do List
============

Many features that can be easily added to CairoSVG are listed in the different
folders of the ``test/fail`` directory.

Look at the roadmap if you don't know where to start:
http://redmine.kozea.fr/projects/cairosvg/roadmap
