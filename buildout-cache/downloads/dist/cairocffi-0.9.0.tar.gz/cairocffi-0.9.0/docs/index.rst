.. include:: ../README.rst


Documentation
-------------

.. toctree::

    overview
    api
    pixbuf
    xcb
    cffi_api
    changelog
