# -*- coding: utf-8 -*-

import logging


logging.basicConfig()
