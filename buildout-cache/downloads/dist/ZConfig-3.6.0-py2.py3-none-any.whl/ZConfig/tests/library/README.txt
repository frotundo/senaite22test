This is a sample library of configuration schema components.  This is
used for testing.
