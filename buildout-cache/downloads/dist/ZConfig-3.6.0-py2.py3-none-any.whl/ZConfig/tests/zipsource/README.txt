This directory contains a sample package that is used to create the
'foosample.zip' file used in the tests.
