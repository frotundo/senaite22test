"""Sample datatypes used for testing.
"""
__docformat__ = "reStructuredText"


def data(value):
    return "| %s |" % value
