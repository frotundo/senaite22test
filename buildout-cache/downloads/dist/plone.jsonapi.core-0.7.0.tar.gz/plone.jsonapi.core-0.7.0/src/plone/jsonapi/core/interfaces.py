# -*- coding: utf-8 -*-

# Convenience imports
from .browser.interfaces import IRouteProvider
from .browser.interfaces import IRouter


# Make Pyflakes happy
IRouter
IRouteProvider
