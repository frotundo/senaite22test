Ramon Bartl, RIDING BYTES GmbH, Author

Stefan Eletzhofer, nexiles GmbH

Campbell Mc Kellar-Basset, Bika Lab Systems (Pty) Ltd

Jeff Terstriep, LEAMgroup Inc

Maurits van Rees, Zest Software BV
