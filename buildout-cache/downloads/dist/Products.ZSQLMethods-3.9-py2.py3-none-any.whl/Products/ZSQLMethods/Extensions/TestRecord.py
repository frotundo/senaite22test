#
#   TestRecord      - Used for ZSQLMethod tests
#


class MyRecord:

    def my_uncle(self):
        """ Bruce is my uncle """
        return 'bruce'
