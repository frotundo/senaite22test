from Products.CMFCore.permissions import AddPortalContent

ADD_CONTENT_PERMISSION = AddPortalContent
PROJECTNAME = 'CMFFormController'
SKINS_DIR = 'skins'
URL_ENCODING = 'utf-8'

GLOBALS = globals()
