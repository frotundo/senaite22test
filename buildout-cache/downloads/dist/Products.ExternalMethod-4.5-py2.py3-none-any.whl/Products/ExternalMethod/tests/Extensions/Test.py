from math import sqrt


def testf(arg1, sqrt=sqrt):
    return sqrt(arg1)
