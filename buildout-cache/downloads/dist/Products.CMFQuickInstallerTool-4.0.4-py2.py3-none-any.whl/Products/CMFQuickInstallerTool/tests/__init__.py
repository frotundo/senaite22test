# -*- coding: utf-8 -*-
"""QuickInstaller tests package."""
