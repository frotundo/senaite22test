PKG_NAME = "DataGridField"
SKIN_NAME = "DataGridWidget"

# See debug messages
DEBUG = False

GLOBALS = globals()
