# -*- coding: utf-8 -*-
# we save all timezone with TZIDs unknow to the TZDB in here
_timezone_cache = {}
