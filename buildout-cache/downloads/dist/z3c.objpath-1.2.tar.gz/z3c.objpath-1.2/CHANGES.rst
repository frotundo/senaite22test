z3c.objpath changes
*******************

1.2 (2018-06-14)
================

* Add support for Python 3.5, 3.6, PyPy and PyPy3.

1.1 (2012-10-13)
================

* Add name space declaration for `z3c`.

* Added a `test` extra, as test require ``zope.testing``.

1.0 (2008-04-15)
================

* Initial public release.
