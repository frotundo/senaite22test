README
======

See src/z3c/objpath/README.rst
