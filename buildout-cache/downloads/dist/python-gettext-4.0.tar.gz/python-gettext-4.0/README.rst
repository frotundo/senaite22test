Overview
========

This implementation of Gettext for Python includes a Msgfmt class which can be
used to generate compiled mo files from Gettext po files and includes support
for the newer msgctxt keyword.

The idea for this project had been rather ambitious, but never lived up to what
is was supposed to do. Look at Babel (http://pypi.python.org/pypi/Babel) for a
project more worthy of this projects name.

Development takes place at https://github.com/hannosch/python-gettext

Contributors
------------

* Hanno Schlichting
* Christian Heimes
* Andrei Polushin
* Michael Howitz
* Steffen Allner
