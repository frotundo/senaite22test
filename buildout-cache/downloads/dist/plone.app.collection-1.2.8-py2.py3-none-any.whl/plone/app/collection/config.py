# -*- coding: utf-8 -*-
PROJECTNAME = 'plone.app.collection'

ADD_PERMISSIONS = {
    'Collection': 'plone.app.collection: Add Collection',
}
ATCT_TOOLNAME = 'portal_atct'
