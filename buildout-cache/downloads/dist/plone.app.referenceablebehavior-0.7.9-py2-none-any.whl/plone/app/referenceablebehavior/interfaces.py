# -*- coding: utf-8 -*-
from plone.app.referenceablebehavior.referenceable import IReferenceable
