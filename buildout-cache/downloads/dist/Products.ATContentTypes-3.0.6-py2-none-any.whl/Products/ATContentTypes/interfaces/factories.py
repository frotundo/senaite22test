# -*- coding: utf-8 -*-
from plone.app.widgets.interfaces import IFileFactory


class IATCTFileFactory(IFileFactory):
    """ adapter factory for ATCT
    """
