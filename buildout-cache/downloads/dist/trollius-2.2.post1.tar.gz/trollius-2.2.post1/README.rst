========
Trollius
========

.. image:: http://unmaintained.tech/badge.svg
   :target: http://unmaintained.tech/
   :alt: No Maintenance Intended

.. warning::
   The Trollius project is deprecated and unsupported. It is on PyPI
   to support existing dependencies only.
