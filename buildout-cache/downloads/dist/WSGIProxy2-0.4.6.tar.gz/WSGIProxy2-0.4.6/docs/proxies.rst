=================
Available proxies
=================

.. automodule:: wsgiproxy.proxies

.. autoclass:: Proxy

.. autoclass:: TransparentProxy

.. autoclass:: HostProxy
