********************************
Buildout Egg-Installation Recipe
********************************

.. contents::

The egg-installation recipe installs eggs into a buildout eggs
directory.  It also generates scripts in a buildout bin directory with 
egg paths baked into them.

