# -*- coding: utf-8 -*-
ManageTranslations = 'plone.app.multilingual: Manage Translations'
