# misc security fixes
from Products.CMFPlone.earlypatches import security  # noqa
from Products.CMFPlone.earlypatches import expressions  # noqa
