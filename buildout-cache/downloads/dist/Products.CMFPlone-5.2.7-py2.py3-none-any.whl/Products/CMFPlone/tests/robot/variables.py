# -*- coding: utf-8 -*-
import os

PATH_TO_TEST_FILES = os.path.join(os.path.dirname(__file__))  # noqa
