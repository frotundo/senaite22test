========================
plone.app.workflow to-do
========================

 Sharing page:

    - Enable settings for the Anonymous user (aka "Everyone")
    - Enable settings for the "Logged in" pseudo-user
        - note, this is not necessarily easy, because there is no user for
          this; it may be possible to make "all users" pseudo-group using
          PAS.
