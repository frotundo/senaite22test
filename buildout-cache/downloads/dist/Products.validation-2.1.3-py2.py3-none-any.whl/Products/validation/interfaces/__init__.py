# backward compatibility
from Products.validation.interfaces.IValidator import IValidator as ivalidator
from Products.validation.interfaces.IValidationService import IValidationService as ivalidationService
