.. currentmodule:: weasyprint
.. include:: ../CHANGES
