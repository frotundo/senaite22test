# coding: utf-8
"""
    weasyprint.tests.test_web
    -------------------------

    A simple web application made with Flask. Allows to type HTML
    and instantly visualize the result rendered by WeasyPrint.

    :copyright: Copyright 2011-2014 Simon Sapin and contributors, see AUTHORS.
    :license: BSD, see LICENSE for details.

"""
