===================
 ``zope.ramcache``
===================


.. image:: https://img.shields.io/pypi/v/zope.ramcache.svg
        :target: https://pypi.python.org/pypi/zope.ramcache/
        :alt: Latest release

.. image:: https://img.shields.io/pypi/pyversions/zope.ramcache.svg
        :target: https://pypi.org/project/zope.ramcache/
        :alt: Supported Python versions

.. image:: https://travis-ci.org/zopefoundation/zope.ramcache.svg?branch=master
        :target: https://travis-ci.org/zopefoundation/zope.ramcache

.. image:: https://coveralls.io/repos/github/zopefoundation/zope.ramcache/badge.svg?branch=master
        :target: https://coveralls.io/github/zopefoundation/zope.ramcache?branch=master


This package provides a RAM-based cache implementation for Zope.

The class ``zope.ramcache.ram.RAMCache`` is a (persistent) object
meant to be shared between threads. It implements
``zope.ramcache.interfaces.ram.IRAMCache``, which provides a simple
interface to cache information as well as defines a maximum number and
age for cached entries.

The cache is based on the idea of using arbitrary objects as keys,
with the ability to associate additional information in the cache key
for any given object. For example, it's possible to cache information
for an object for multiple different users simultaneously.


=========
 Changes
=========

2.3 (2018-10-10)
================

- Add support for Python 3.7.


2.2.0 (2017-09-05)
==================

- Add support for Python 3.5 and 3.6.

- Drop support for Python 2.6 and 3.3.

- Drop support for ``python setup.py test``.

- Test PyPy3 on Travis CI.

- Stop requiring all values to support pickling in order to get
  statistics. Instead, return ``False`` for the size if such a value
  is found. Fixes `issue 1 <https://github.com/zopefoundation/zope.ramcache/issues/1>`_.

- Change the internal storage format of the RAM cache to require less
  memory and be easier to maintain.

2.1.0 (2014-12-29)
==================

- Added support for PyPy.  (PyPy3 is pending release of a fix for:
  https://bitbucket.org/pypy/pypy/issue/1946)

- Add support for Python 3.4.

- Add support for testing on Travis.


2.0.0 (2013-02-28)
==================

- Add support for Python 3.3.

- Replace deprecated ``zope.interface.implements`` usage with equivalent
  ``zope.interface.implementer`` decorator.

- Drop support for Python 2.4 and 2.5.

- Remove outdated classifier / keywords.

1.0 (2009-07-23)
================

- Broke out the ram cache functionality from ``zope.app.cache``.


