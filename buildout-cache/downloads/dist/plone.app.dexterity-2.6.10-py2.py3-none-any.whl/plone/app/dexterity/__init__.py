# -*- coding: utf-8 -*-
from zope.i18nmessageid import MessageFactory as ZMessageFactory

import warnings


_ = ZMessageFactory('plone')

