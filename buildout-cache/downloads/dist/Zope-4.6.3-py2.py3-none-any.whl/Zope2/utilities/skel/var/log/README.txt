This folder is for Zope log files.
