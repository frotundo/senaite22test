# BBB
from ZPublisher.BeforeTraverse import NameCaller as AccessRule  # noqa: F401
