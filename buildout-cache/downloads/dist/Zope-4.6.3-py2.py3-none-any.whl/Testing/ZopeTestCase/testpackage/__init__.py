def initialize(context):
    print('testpackage.initialize called')
