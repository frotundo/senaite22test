2.2.0 (2022-06-10)
------------------

- #27 Use searchable text index converter from catalog API
- #26 Improve spotlight search results


2.1.0 (2022-01-05)
------------------

- #25 Changed catalog imports for compatibility with senaite.core#1872
- Updated resources


2.0.0 (2021-07-26)
------------------

- #7 Use absolute portal URL for spotlight JS


2.0.0rc3 (2021-01-04)
---------------------

- Updated resources
- Updated build system to Webpack 5


2.0.0rc2 (2020-10-13)
---------------------

- Updated resources


2.0.0rc1 (2020-08-05)
---------------------

- Compatibility with `senaite.core` 2.x


1.0.3 (2020-08-04)
------------------

- updated resources


1.0.2 (2020-03-02)
------------------

- #2 Fix visible spotlight viewlet on page load
- #1 Added missing dependency to `senaite.jsonapi`


1.0.1 (2020-02-04)
------------------

- Minimized JS code from 124K to 53K


1.0.0 (2020-02-04)
------------------

- Initial release
