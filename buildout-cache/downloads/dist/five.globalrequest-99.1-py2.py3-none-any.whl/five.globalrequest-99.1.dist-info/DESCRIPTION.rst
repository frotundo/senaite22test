Overview
========

This package is deprecated. It was integrated into Zope at version 4.0a3.
It is no longer needed.

Changelog
=========

99.1 (2017-06-08)
-----------------

- Fixed wrong dependency in install requires.

99.0 (2017-06-01)
-----------------

- Mark as deprecated.

1.0 - 2010-08-06
----------------

- Changes not recorded.

1.0a2 - 2010-01-08
------------------

- Initial release


