Change log
==========

4.0 (2019-05-10)
----------------

- Add support for Python 3.7 and 3.8a3.

- Drop support for Python 3.4.


4.0b1 (2017-09-18)
------------------

* Move all the code to the ``Zope`` package. Making this package a placeholder.

Older releases see https://pypi.org/project/Zope2/#history
