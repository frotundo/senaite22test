Zope2
=====

This package is a meta package to allow to install ``Zope`` as ``Zope2``.
It is necessary because ``Zope`` previously was named ``Zope2`` on PyPI.

Documentation see https://zope.readthedocs.io
