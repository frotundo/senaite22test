# -*- coding: utf-8 -*-
from plone.protect.authenticator import check as CheckAuthenticator
from plone.protect.authenticator import createToken
from plone.protect.authenticator import CustomCheckAuthenticator
from plone.protect.postonly import check as PostOnly
from plone.protect.utils import protect
