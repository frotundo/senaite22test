# -*- coding: utf-8 -*-
# Configuration constants

LOCALROLE_PLUGIN_NAME = 'borg_localroles'
