# -*- coding: utf-8 -*-
# Kick dynamic module factory
from . import schema  # noqa
