# -*- coding: utf-8 -*-
import zope.i18nmessageid


MessageFactory = zope.i18nmessageid.MessageFactory("plone")
