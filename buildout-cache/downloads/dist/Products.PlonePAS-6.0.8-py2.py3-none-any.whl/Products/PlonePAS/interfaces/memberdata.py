# -*- coding: utf-8 -*-
from Products.CMFCore import interfaces


class IMemberDataTool(interfaces.IMemberDataTool):
    """More specific PlonePAS MemberDataTool interface.
    """


__all__ = (IMemberDataTool,)
