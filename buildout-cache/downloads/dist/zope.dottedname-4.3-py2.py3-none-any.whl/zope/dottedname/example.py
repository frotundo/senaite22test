# sample module for testing

def example():  # pragma: NO COVER
    pass
