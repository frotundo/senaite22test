# -*- coding: utf-8 -*-
"""FIXME: backward compat, remove later
"""
from Products.PortalTransforms.chain import Chain as TransformsChain
