## Script (Python) "session_restore_value"
##bind container=container
##bind context=context
##bind namespace=
##bind script=script
##bind subpath=traverse_subpath
##parameters=fieldName,default
##title=Return field value previously stored on session by session_save_form
##

return default
