## Script (Python) "getCharset"
##title=Return the site charset
##bind container=container
##bind context=context
##bind namespace=
##bind script=script
##bind subpath=traverse_subpath
##parameters=
return 'utf-8'
