# -*- coding: utf-8 -*-

# # Required to use the REST API at all, in addition to service specific
# permissions. Granted to Anonymous (i.e. everyone) by default via rolemap.xml

UseRESTAPI = "plone.restapi: Use REST API"
