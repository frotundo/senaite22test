.. _breadcrumbs:

Breadcrumbs
===========

Getting the breadcrumbs for the current page:

..  http:example:: curl httpie python-requests
    :request: ../../src/plone/restapi/tests/http-examples/breadcrumbs.req

Example response:

.. literalinclude:: ../../src/plone/restapi/tests/http-examples/breadcrumbs.resp
   :language: http
