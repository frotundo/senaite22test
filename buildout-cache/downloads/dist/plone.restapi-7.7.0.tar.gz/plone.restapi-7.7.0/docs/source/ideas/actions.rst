Actions Draft
-------------

Actions::

  {
    "@id": "http://localhost:8080/Plone/"
    "@type": "Folder",
    "actions": [
      {
          "@type": "Create",
          "method": "POST"
      },
      {
          "@type": "Replace",
          "method": "PATCH"
      },
      {
          "@type": "Delete"
          "method": "DELETE"
      },
      {
          "@type": "Cut"
          "method": "POST"
      },
      {
          "@type": "Copy"
          "method": "POST"
      },
      {
          "@type": "Paste"
          "method": "POST"
      },
      {
          "@type": "Rename"
          "method": "POST"
      },
    }
  }
