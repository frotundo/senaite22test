# Test package for locales
