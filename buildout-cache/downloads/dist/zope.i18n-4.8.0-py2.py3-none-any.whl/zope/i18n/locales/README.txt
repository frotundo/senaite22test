=================
Locales XML Files
=================

The XML locale files were produced as part of the Unicode Common Locale
Data Repository (CLDR). They are provided here under the Unicode Terms of
Use (see http://unicode.org/copyright.html). 


CLDR Web site
-------------

  http://www.unicode.org/cldr/


Locale Data Markup Language
---------------------------

The XML files follow the now public and completed LDML format. 

The DTD can be found at

  http://www.unicode.org/cldr/dtd/1.1/ldml.dtd

The specification is at

  http://www.unicode.org/reports/tr35/tr35-2.html


Download::

  http://www.unicode.org/cldr/repository_access.html
