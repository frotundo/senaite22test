# -*- coding: utf-8 -*-
# Import PloneMessageFactory to create messages in the plone domain
from zope.i18nmessageid import MessageFactory


PloneMessageFactory = MessageFactory('plone')
