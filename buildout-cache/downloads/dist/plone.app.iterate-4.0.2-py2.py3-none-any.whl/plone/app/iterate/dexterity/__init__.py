# -*- coding: utf-8 -*-

ITERATE_RELATION_NAME = "iterate-working-copy"
