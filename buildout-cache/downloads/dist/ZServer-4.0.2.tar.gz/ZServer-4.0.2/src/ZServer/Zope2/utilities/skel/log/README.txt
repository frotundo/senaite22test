This is the directory used to hold log files by default.
