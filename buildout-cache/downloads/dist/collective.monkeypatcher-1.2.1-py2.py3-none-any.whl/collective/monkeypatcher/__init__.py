# -*- coding: utf-8 -*-
"""collective.monkeypatcher"""
