# -*- coding: utf-8 -*-
"""Testing collective.monkeypatcher"""
