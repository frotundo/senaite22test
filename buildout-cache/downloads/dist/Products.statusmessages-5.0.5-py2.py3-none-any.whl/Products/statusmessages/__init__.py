# -*- coding: utf-8 -*-
STATUSMESSAGEKEY = 'statusmessages'
