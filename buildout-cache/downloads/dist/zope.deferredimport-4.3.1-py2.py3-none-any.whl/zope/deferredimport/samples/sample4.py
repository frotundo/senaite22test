
import sample3

def getone():
    return sample3.one

