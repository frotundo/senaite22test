PluggableAuthService Extensions

  ExternalMethod implementations, intended primarily for illustrating
  how plugins work within the PluggableAuthService framework, and for
  functional testing of the framework itself.
