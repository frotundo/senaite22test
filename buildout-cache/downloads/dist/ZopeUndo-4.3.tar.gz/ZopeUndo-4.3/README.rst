Overview
========

This package is used to support the Prefix object that Zope 2 uses for the
undo log. It is a separate package only to aid configuration management.

This package is included in Zope 2. It can be used in a ZEO server to allow
it to support Zope 2's undo log , without pulling in all of Zope 2.
